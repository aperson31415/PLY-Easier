import ply
import ply.lex as lex
import ply.yacc as yacc
import math
import random
import sys

tokens = ("PLUS", "MINUS", "DIVIDE", "MULTIPLY", "POWER", "MODULO",
          "GREATER_THAN", "LESS_THAN", "EQUAL_TO", "NOT_EQUAL",
          "GREATER_OR_EQUAL", "LESS_OR_EQUAL",
          "ROUND",
          "RANDOM", "SQRT", "FLOOR", "CEILING",
          "SIN", "COS", "TAN", #add other trigonometric functions
          "PRINT", "ERROR",
          "INT", "BOOL", "DEC",
          "PARENTHESES_L", "PARENTHESES_R", "COMMENT", "DECIMALPOINT")

precedence = (
    ('left', 'PRINT', 'ERROR'),
    ('left', 'SIN', 'COS', 'TAN', 'SQRT'),
    ('left', 'FLOOR', 'CEILING', 'ROUND'),
    ('left', 'RANDOM'),
    ('left', 'GREATER_THAN', 'LESS_THAN', 'EQUAL_TO', 'NOT_EQUAL',
     'GREATER_OR_EQUAL', 'LESS_OR_EQUAL'),
    ('left', 'PLUS', 'MINUS'),
    ('left', 'MULTIPLY', 'DIVIDE'),
    ('left', 'MODULO', 'POWER'),
    ('left', 'INT', 'BOOL', 'DEC'),
    ('right', 'COMMENT')
    )

#define tokens
t_PLUS = R'\+'
t_MINUS = R'-'
t_DIVIDE = R'/'
t_MULTIPLY = R'\*'
t_POWER = R'\^'
t_MODULO = R'mod'
t_GREATER_THAN = R'>'
t_LESS_THAN = R'<'
t_EQUAL_TO = R'=='
t_NOT_EQUAL = R'!='
t_GREATER_OR_EQUAL = R'>='
t_LESS_OR_EQUAL = R'<='
t_ROUND = R'round'
t_RANDOM = R'random'
t_SQRT = R'sqrt'
t_FLOOR = R'floor'
t_CEILING = R'ceil'
t_SIN = R'sin'
t_COS = R'cos'
t_TAN = R'tan'
t_PRINT = R'print'
t_ERROR = R'error'
t_PARENTHESES_L = R'\('
t_PARENTHESES_R = R'\)'
t_DECIMALPOINT = r'.'

def t_INT(t):
    r'\d+'
    t.value = int(t.value)
    return t
def t_BOOL(t):
    R'True|False'
    t.value = bool(t.value)
    return t
def t_DEC(t):
    R'\d+\.\d+'
    t.value = float(t.value)
    return t

#errors and chars
t_ignore = ' \t'
def t_error(t):
    print(f"Illegal Character '{t.value[0]}'")
    t.lexer.skip(1)
def p_error(t):
    print(f"Syntax Error\n{t}", file=sys.stderr)
def t_COMMENT(t):
        r'\#.*'
        t.type = 'COMMENT'
        t.lineno += t.value.count('\n')
        return None 

#for compiling
def p_expression_operators(p):
    '''expression : expression PLUS expression
                | expression MINUS expression
                | expression DIVIDE expression
                | expression MULTIPLY expression
                | expression POWER expression
                | expression MODULO expression'''
    if p[2] == '+':
        p[0] = p[1] + p[3]
    elif p[2] == '-':
        p[0] = p[1] - p[3]
    elif p[2] == '/':
        p[0] = p[1] / p[3]
    elif p[2] == '*':
        p[0] = p[1] * p[3]
    elif p[2] == '^':
        p[0] = p[1] ** p[3]
    elif p[2] == 'mod':
        p[0] = p[1] % p[3]
def p_expression_basiclogic(p):
    '''expression : expression GREATER_THAN expression
                | expression LESS_THAN expression
                | expression EQUAL_TO expression
                | expression NOT_EQUAL expression
                | expression GREATER_OR_EQUAL expression
                | expression LESS_OR_EQUAL expression'''
    if p[2] == '>':
        p[0] = p[1] > p[3]
    elif p[2] == '<':
        p[0] = p[1] < p[3]
    elif p[2] == '==':
        p[0] = p[1] == p[3]
    elif p[2] == '!=':
        p[0] = p[1] != p[3]
    elif p[2] == '>=':
        p[0] = p[1] >= p[3]
    elif p[2] == '<=':
        p[0] == p[1] <= p[3]
def p_expression_basicfunct(p):
    '''expression : ROUND PARENTHESES_L expression PARENTHESES_R
                | RANDOM PARENTHESES_L expression expression PARENTHESES_R
                | SQRT PARENTHESES_L expression PARENTHESES_R
                | FLOOR PARENTHESES_L expression PARENTHESES_R
                | CEILING PARENTHESES_L expression PARENTHESES_R
                | SIN PARENTHESES_L expression PARENTHESES_R
                | COS PARENTHESES_L expression PARENTHESES_R
                | TAN PARENTHESES_L expression PARENTHESES_R'''
    if p[1] == 'round':
        p[0] = round(p[3])
    elif p[1] == 'random':
        p[0] = random.randint(p[3], p[4])
    elif p[1] == 'sqrt':
        p[0] = math.sqrt(p[3])
    elif p[1] == 'floor':
        p[0] = math.floor(p[3])
    elif p[1] == 'ceil':
        p[0] = math.ceil(p[3])
    elif p[1] == 'sin':
        p[0] = math.sin(p[3])
    elif p[1] == 'cos':
        p[0] = math.cos(p[3])
    elif p[1] == 'tan':
        p[0] = math.tan(p[3])
#data types
def p_expression_int(p):
    '''expression : INT'''
    p[0] = int(p[1])
def p_expression_bool(p):
    '''expression : BOOL'''
    p[0] = bool(p[1])
def p_expression_dec(p):
    '''expression : INT DECIMALPOINT INT'''
    p.type = "DEC"
    p[0] = p[1] + (10**(-1*len(str(p[3]))))*p[3]
def p_expression_output(p):
    '''expression : PRINT PARENTHESES_L expression PARENTHESES_R
                | ERROR PARENTHESES_L expression PARENTHESES_R'''
    if p[1] == 'print':
        print(p[3], file=sys.stdout)
    elif p[1] == 'error':
        print(p[3], file=sys.stderr)
def p_expression_brackets(p):
    '''expression : PARENTHESES_L expression PARENTHESES_R'''
    p[0] = p[2]

while True:
    code = input('Expression: ')
    if not ('.' in code):
        code += ' + 0.0'
    if not ('#' in code):
        code += ' #'
    
    parser = yacc.yacc()
    
    # Example parsing
    lexer = lex.lex()
    lexer.input(code)
    while True:
        tok = lexer.token()
        if not tok:
            break
        print(f"{tok.type}, {tok.value}")
    
    result = parser.parse(code)
    if round(result) == result:
        result = int(result)
    print("Result:", result)
